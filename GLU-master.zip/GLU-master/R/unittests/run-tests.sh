

Rscript test-getUserIDFromFileName.R

Rscript test-auc.R

Rscript test-SGVP.R

Rscript test-timeToPeak.R

Rscript test-fastingProxy.R

Rscript test-postprandial.R

Rscript test-timeProportions.R

Rscript test-markLargeDeviations.R

Rscript test-invalidDeviationsByDay.R

Rscript test-getDays.R


